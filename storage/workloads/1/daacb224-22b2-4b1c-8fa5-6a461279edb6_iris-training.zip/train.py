from pathlib import Path
import os
import joblib
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report

# FluxCompute convention: save generated artifacts under /workspace/output.
output_dir = Path(os.environ.get("FLUXCOMPUTE_OUTPUT_DIR", "/workspace/output"))
output_dir.mkdir(parents=True, exist_ok=True)

print("Loading the built-in Iris dataset...")
iris = load_iris()
X_train, X_test, y_train, y_test = train_test_split(
    iris.data, iris.target, test_size=0.2, random_state=42, stratify=iris.target
)

print("Training Logistic Regression model...")
model = make_pipeline(
    StandardScaler(),
    LogisticRegression(max_iter=1000, random_state=42)
)
model.fit(X_train, y_train)

predictions = model.predict(X_test)
accuracy = accuracy_score(y_test, predictions)
print(f"Test accuracy: {accuracy:.3f}")
print("Classification report:")
print(classification_report(y_test, predictions, target_names=iris.target_names))

model_path = output_dir / "iris_model.joblib"
joblib.dump(
    {
        "model": model,
        "target_names": iris.target_names.tolist(),
        "feature_names": iris.feature_names,
    },
    model_path,
)
print(f"Saved trained model artifact: {model_path}")
print("FluxCompute Iris training job completed successfully.")
