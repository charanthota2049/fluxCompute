# Iris Training Workload for FluxCompute

## Files
- `train.py`: trains a Logistic Regression classifier using scikit-learn's built-in Iris dataset.
- `requirements.txt`: Python dependencies.

## Run inside the FluxCompute Python 3.12 container
The workload expects the files to be mounted at `/workspace`.

```bash
pip install -r /workspace/requirements.txt
python /workspace/train.py
```

## Output
The trained model is written to:
`/workspace/output/iris_model.joblib`

You can override the output directory with `FLUXCOMPUTE_OUTPUT_DIR`.
The script uses `sklearn.datasets.load_iris`, so it does not download a dataset.
